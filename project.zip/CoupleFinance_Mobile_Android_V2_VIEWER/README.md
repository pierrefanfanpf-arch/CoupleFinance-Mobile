COUPLE FINANCE MOBILE V2 — VIEWER + SAISIE

OBJECTIF
- Visualiser sur le téléphone les principales données de Couple Finance PC.
- Toutes les pages de consultation sont en lecture seule.
- La seule zone modifiable est Saisie : Dépense, Revenu, Transaction, Épargne et Événement.

LIAISON
Le PC et le téléphone utilisent le même dossier OneDrive.
- CoupleFinance_Mobile_View.json : écrit automatiquement par Couple Finance PC; lu seulement par le téléphone.
- CoupleFinance_Mobile.xlsx : le téléphone y ajoute les saisies; Couple Finance PC les importe.

PREMIÈRE UTILISATION
1. Installer la V1.40.7 de Couple Finance PC.
2. Dans Mobile & synchro, choisir/créer CoupleFinance_Mobile.xlsx dans OneDrive.
3. Cliquer une fois sur « Actualiser maintenant la vue téléphone ».
4. Compiler/installer Couple Finance Mobile V2.
5. Dans l'application Android, cliquer « Connecter OneDrive » et sélectionner le même dossier.
6. L'application mémorise ce dossier.

LECTURE SEULE
Accueil, Comptes, Revenus, Dépenses, Transactions, Dettes, Épargne et Agenda n'ont aucune action de modification.

SAISIES
La page Saisie peut uniquement ajouter de nouvelles lignes dans CoupleFinance_Mobile.xlsx.
Le PC reste la source officielle et applique les calculs/soldes lors de l'import.

COMPILATION
Ouvrir ce dossier dans Android Studio, attendre Gradle Sync, puis :
Build > Build APK(s)
APK attendu :
app\build\outputs\apk\debug\app-debug.apk
