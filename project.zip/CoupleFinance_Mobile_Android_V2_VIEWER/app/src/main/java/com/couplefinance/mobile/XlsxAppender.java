package com.couplefinance.mobile;

import android.content.ContentResolver;
import android.net.Uri;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

final class XlsxAppender {
    static final class Entry {
        String date, time, owner, type, category, description, account, note;
        double amount;
    }

    private static final Pattern ROW = Pattern.compile("<x:row\\b[^>]*\\br=\"(\\d+)\"[^>]*>(.*?)</x:row>", Pattern.DOTALL);
    private static final Pattern CELL_VALUE = Pattern.compile("<(?:x:)?(?:v|t)>.*?</(?:x:)?(?:v|t)>", Pattern.DOTALL);

    static void append(ContentResolver resolver, Uri uri, Entry e) throws Exception {
        Map<String, byte[]> zip = readZip(resolver.openInputStream(uri));
        String sheetPath = "xl/worksheets/sheet1.xml";
        byte[] sheetBytes = zip.get(sheetPath);
        if (sheetBytes == null) throw new Exception("Feuille Excel introuvable dans le fichier choisi.");
        String xml = new String(sheetBytes, StandardCharsets.UTF_8);

        Matcher m = ROW.matcher(xml);
        int chosen = -1;
        String chosenInner = null;
        int lastRow = 4;
        while (m.find()) {
            int r = Integer.parseInt(m.group(1));
            if (r > lastRow) lastRow = r;
            if (r >= 5 && chosen < 0 && !CELL_VALUE.matcher(m.group(2)).find()) {
                chosen = r;
                chosenInner = m.group(2);
            }
        }
        if (chosen < 0) chosen = Math.max(5, lastRow + 1);

        String newRow = buildRow(chosen, chosenInner, e);
        Pattern target = Pattern.compile("<x:row\\b[^>]*\\br=\"" + chosen + "\"[^>]*>.*?</x:row>", Pattern.DOTALL);
        Matcher targetMatcher = target.matcher(xml);
        if (targetMatcher.find()) {
            xml = targetMatcher.replaceFirst(Matcher.quoteReplacement(newRow));
        } else {
            int p = xml.indexOf("</x:sheetData>");
            if (p < 0) throw new Exception("Structure Excel non reconnue.");
            xml = xml.substring(0, p) + newRow + xml.substring(p);
        }

        zip.put(sheetPath, xml.getBytes(StandardCharsets.UTF_8));
        writeZip(resolver, uri, zip);
    }

    private static String buildRow(int r, String existingInner, Entry e) {
        String[] text = new String[]{e.date, e.time, e.owner, e.type, null, e.category, e.description, e.account, e.note, "Téléphone", "", ""};
        String[] cols = new String[]{"A","B","C","D","E","F","G","H","I","J","K","L"};
        StringBuilder sb = new StringBuilder();
        sb.append("<x:row r=\"").append(r).append("\">");
        for (int i = 0; i < cols.length; i++) {
            String style = styleFor(existingInner, cols[i] + r);
            if (i == 4) {
                sb.append("<x:c r=\"").append(cols[i]).append(r).append("\"").append(style).append("><x:v>")
                  .append(Double.toString(Math.abs(e.amount))).append("</x:v></x:c>");
            } else {
                String v = text[i] == null ? "" : text[i];
                sb.append("<x:c r=\"").append(cols[i]).append(r).append("\"").append(style)
                  .append(" t=\"inlineStr\"><x:is><x:t xml:space=\"preserve\">")
                  .append(escapeXml(v)).append("</x:t></x:is></x:c>");
            }
        }
        sb.append("</x:row>");
        return sb.toString();
    }

    private static String styleFor(String inner, String ref) {
        if (inner == null) return "";
        Pattern p = Pattern.compile("<x:c\\b[^>]*\\br=\"" + Pattern.quote(ref) + "\"[^>]*>");
        Matcher m = p.matcher(inner);
        if (!m.find()) {
            p = Pattern.compile("<x:c\\b[^>]*\\br=\"" + Pattern.quote(ref) + "\"[^>]*/>");
            m = p.matcher(inner);
            if (!m.find()) return "";
        }
        Matcher s = Pattern.compile("\\bs=\"(\\d+)\"").matcher(m.group());
        return s.find() ? " s=\"" + s.group(1) + "\"" : "";
    }

    private static String escapeXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    private static Map<String, byte[]> readZip(InputStream in) throws Exception {
        if (in == null) throw new Exception("Impossible d'ouvrir le fichier Excel.");
        Map<String, byte[]> map = new LinkedHashMap<>();
        try (ZipInputStream zin = new ZipInputStream(in)) {
            ZipEntry ze;
            byte[] buf = new byte[8192];
            while ((ze = zin.getNextEntry()) != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                int n;
                while ((n = zin.read(buf)) > 0) out.write(buf, 0, n);
                map.put(ze.getName(), out.toByteArray());
            }
        }
        return map;
    }

    private static void writeZip(ContentResolver resolver, Uri uri, Map<String, byte[]> map) throws Exception {
        ByteArrayOutputStream all = new ByteArrayOutputStream();
        try (ZipOutputStream zout = new ZipOutputStream(all)) {
            for (Map.Entry<String, byte[]> it : map.entrySet()) {
                ZipEntry ze = new ZipEntry(it.getKey());
                zout.putNextEntry(ze);
                zout.write(it.getValue());
                zout.closeEntry();
            }
        }
        OutputStream out = resolver.openOutputStream(uri, "wt");
        if (out == null) out = resolver.openOutputStream(uri, "w");
        if (out == null) throw new Exception("Le fournisseur de fichiers refuse l'écriture.");
        try (OutputStream os = out) {
            os.write(all.toByteArray());
            os.flush();
        }
    }
}
