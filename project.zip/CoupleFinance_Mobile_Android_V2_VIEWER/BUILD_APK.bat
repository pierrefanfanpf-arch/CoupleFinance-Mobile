@echo off
setlocal
echo ==================================================
echo Couple Finance Mobile V2 - Build APK
echo ==================================================
where gradlew.bat >nul 2>nul
if exist gradlew.bat (
  call gradlew.bat assembleDebug
) else (
  echo.
  echo Ouvrez ce dossier dans Android Studio.
  echo Puis : Build ^> Build APK(s)
  echo.
  echo Si Android Studio a cree gradlew.bat, relancez ce fichier.
  pause
  exit /b 1
)
if errorlevel 1 (
  echo ECHEC DE COMPILATION
  pause
  exit /b 1
)
copy /Y "app\build\outputs\apk\debug\app-debug.apk" "CoupleFinance_Mobile_V2.apk" >nul
echo.
echo APK cree : CoupleFinance_Mobile_V2.apk
pause
