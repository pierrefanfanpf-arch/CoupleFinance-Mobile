$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$tools = Join-Path $root '.build-tools'
$log = Join-Path $root 'BUILD_LOG.txt'
$apkOut = Join-Path $root 'CoupleFinance_Mobile_V1.1.apk'
New-Item -ItemType Directory -Force -Path $tools | Out-Null
"Couple Finance Mobile - build started $(Get-Date -Format s)" | Set-Content -Encoding UTF8 $log

function Log($m) { $m | Tee-Object -FilePath $log -Append | Write-Host }
function Download-Verified($Url, $OutFile, $Sha256) {
    if (Test-Path $OutFile) {
        $h=(Get-FileHash -Algorithm SHA256 $OutFile).Hash.ToLowerInvariant()
        if ($h -eq $Sha256.ToLowerInvariant()) { Log "OK cache: $([IO.Path]::GetFileName($OutFile))"; return }
        Remove-Item -Force $OutFile
    }
    Log "Telechargement: $Url"
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $OutFile
    $h=(Get-FileHash -Algorithm SHA256 $OutFile).Hash.ToLowerInvariant()
    if ($h -ne $Sha256.ToLowerInvariant()) { throw "Checksum invalide pour $OutFile. Recu=$h" }
}
function Find-Java17 {
    try {
        $j=(Get-Command java.exe -ErrorAction Stop).Source
        $v=& $j -version 2>&1 | Select-Object -First 1
        if ($v -match '"(\d+)') { if ([int]$Matches[1] -ge 17) { return $j } }
    } catch {}
    $candidates=@(
      "$env:ProgramFiles\Eclipse Adoptium\jdk-17*\bin\java.exe",
      "$env:ProgramFiles\Java\jdk-17*\bin\java.exe",
      "$env:ProgramFiles\Android\Android Studio\jbr\bin\java.exe"
    )
    foreach($pat in $candidates){$f=Get-ChildItem $pat -ErrorAction SilentlyContinue | Select-Object -First 1;if($f){return $f.FullName}}
    return $null
}

try {
    Log "1/5 Verification Java"
    $java = Find-Java17
    if (-not $java) {
        Log "Java 17+ absent. Installation automatique de Temurin 17 avec winget..."
        $wg=Get-Command winget.exe -ErrorAction SilentlyContinue
        if(-not $wg){ throw "Java 17+ est requis et winget n'est pas disponible. Installez Java 17 puis relancez BUILD_APK.bat." }
        & winget install --id EclipseAdoptium.Temurin.17.JDK -e --silent --accept-package-agreements --accept-source-agreements | Tee-Object -FilePath $log -Append
        $java=Find-Java17
        if(-not $java){throw "Java 17 n'a pas ete detecte apres l'installation."}
    }
    $javaHome=Split-Path -Parent (Split-Path -Parent $java)
    $env:JAVA_HOME=$javaHome
    $env:Path="$javaHome\bin;$env:Path"
    Log "Java: $javaHome"

    Log "2/5 Installation des outils Android"
    $sdkRoot=Join-Path $tools 'android-sdk'
    $cmdZip=Join-Path $tools 'commandlinetools-win-15859902_latest.zip'
    $cmdSha='90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
    Download-Verified 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' $cmdZip $cmdSha
    $sdkManager=Join-Path $sdkRoot 'cmdline-tools\latest\bin\sdkmanager.bat'
    if(-not (Test-Path $sdkManager)){
        $tmp=Join-Path $tools 'cmdline-unpack'
        Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
        New-Item -ItemType Directory -Force -Path $tmp,$sdkRoot | Out-Null
        Expand-Archive -Path $cmdZip -DestinationPath $tmp -Force
        $latest=Join-Path $sdkRoot 'cmdline-tools\latest'
        New-Item -ItemType Directory -Force -Path (Split-Path $latest) | Out-Null
        Remove-Item -Recurse -Force $latest -ErrorAction SilentlyContinue
        Move-Item (Join-Path $tmp 'cmdline-tools') $latest
        Remove-Item -Recurse -Force $tmp
    }
    $env:ANDROID_SDK_ROOT=$sdkRoot
    $env:ANDROID_HOME=$sdkRoot
    $yes = 1..80 | ForEach-Object { 'y' }
    $yes | & $sdkManager "--sdk_root=$sdkRoot" --licenses 2>&1 | Tee-Object -FilePath $log -Append | Out-Host
    & $sdkManager "--sdk_root=$sdkRoot" 'platforms;android-35' 'build-tools;35.0.0' 'platform-tools' 2>&1 | Tee-Object -FilePath $log -Append | Out-Host

    Log "3/5 Installation de Gradle 8.9"
    $gradleZip=Join-Path $tools 'gradle-8.9-bin.zip'
    $gradleSha='d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab'
    Download-Verified 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' $gradleZip $gradleSha
    $gradleDir=Join-Path $tools 'gradle-8.9'
    if(-not (Test-Path (Join-Path $gradleDir 'bin\gradle.bat'))){
        Expand-Archive -Path $gradleZip -DestinationPath $tools -Force
    }

    Log "4/5 Compilation APK"
    Push-Location $root
    try {
        & (Join-Path $gradleDir 'bin\gradle.bat') --no-daemon :app:assembleDebug 2>&1 | Tee-Object -FilePath $log -Append | Out-Host
        if($LASTEXITCODE -ne 0){throw "Gradle a retourne le code $LASTEXITCODE"}
    } finally { Pop-Location }

    $built=Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
    if(-not (Test-Path $built)){throw "Gradle n'a pas produit app-debug.apk."}
    Copy-Item -Force $built $apkOut
    $size=[math]::Round((Get-Item $apkOut).Length/1MB,2)
    Log "5/5 Termine: $apkOut ($size MB)"
    Log "L'APK debug est signe automatiquement par Android Gradle Plugin et peut etre installe sur Android."
    Start-Process explorer.exe "/select,`"$apkOut`""
    exit 0
} catch {
    Log "ERREUR: $($_.Exception.Message)"
    Log $_.ScriptStackTrace
    exit 1
}
